#Discovery
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 ;

#Discovery
Invoke-BloodHound -CollectionMethod All;

#Antivirus Check T1518.001-6
Powershell.exe wmic.exe /Namespace:\\root\SecurityCenter2 Path AntiVirusProduct Get displayName /Format:List;
