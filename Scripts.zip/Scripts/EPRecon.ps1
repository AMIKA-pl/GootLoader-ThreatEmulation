whoami
hostname
cmd.exe /c echo %userdomain%
