#Execution
Regsvr32 "C:\Tools\mal.dll"