<#
Cleanup Commands
NOTE: You can opt to revert to snapshot to restore previous state
#>

#Unregister DLL
Regsvr32 /u “C:\Tools\mal.dll";

#Remove Scheduled Tasks
Unregister-ScheduledTask -TaskName T1053_005_OnLogon -Confirm:$false
Unregister-ScheduledTask -TaskName T1053_005_OnStartup -Confirm:$false

#Delete Bloodhound files
Remove-Item C:\Users\studentadmin\*BloodHound.zip -Force;
